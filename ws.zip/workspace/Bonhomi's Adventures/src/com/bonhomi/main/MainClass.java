package com.bonhomi.main;

import java.awt.Dimension;

import javax.swing.JFrame;
import javax.swing.JPanel;

public class MainClass {

	public static void main(String[] args) {
		Fenetre fenetre = new Fenetre();
	}
}
